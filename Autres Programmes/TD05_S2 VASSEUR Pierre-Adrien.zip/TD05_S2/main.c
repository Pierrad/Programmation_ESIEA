#include "fonctions.h"

int main(){	
	unsigned int a=1234,b=16,c=42;
    if(!puissance(b))
    {
        return 0;
    }
	printf("%d\n",ExpoPuiss2(a,b,c));		
	return 0;
}
