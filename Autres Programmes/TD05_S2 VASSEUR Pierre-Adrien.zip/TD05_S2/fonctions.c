#include "fonctions.h"

int NbDigit(int n){
	
    int nb=0;
    do{
        n/=10;
        nb++;
    }while(n>0);
    return nb;
}

int Miror2(int n,int nb){
	int reste=0, puissance, puissance2, a=0, res=0;
	
	while(nb!=0){
		puissance=pow(10,nb-1);
		puissance2=pow(10,a);
		reste=n/puissance;
		n-=reste*puissance;
		res+=reste*puissance2;
		nb--;
		a++;
		
	}
	return res;	
}	
void NbMiroir(){
	int n,nb;
	printf("Entrez un nombre\n");
	scanf("%d",&n);
	nb=NbDigit(n);
	n=Miror2(n,nb);
	printf("%d\n",n);	
}

unsigned int ExpoNaiveIte(unsigned int g,unsigned int e,unsigned int n){
	int i;
	unsigned int resultat=1;
	for(i=1;i<=e;i++)
    {
		resultat*=g;
		resultat%=n;
	}
				
	return resultat;
}

int puissance(int a){
    if(a%2 != 0)
    {
        return 0;
    }
    else 
    {
        if(a == 2)
        {
            return 1;
        }
        else 
            return puissance(a/2);
    }
}
    

unsigned int ExpoPuiss2(unsigned int g,unsigned int e,unsigned int n){
	
	if(e==1)
    {
		return g;		
	}
    
    g%=n;
	return ExpoPuiss2(g*g,e/2,n);	
}

