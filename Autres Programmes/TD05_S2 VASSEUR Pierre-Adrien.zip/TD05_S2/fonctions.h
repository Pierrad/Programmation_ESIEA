#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int Miror2(int n,int nb);
int NbDigit(int n);
void NbMiroir();
int puissance(int a); // Permet de verifier si cest une puissance de deux
unsigned int ExpoNaiveIte(unsigned int g,unsigned int e,unsigned int n); // retourne la valeur de ge mod n
unsigned int ExpoPuiss2(unsigned int g,unsigned int e,unsigned int n); // retourne la valeur de ge mod n 